


import dash
import datetime as dt
import pandas as pd
import numpy as np
from dash.dependencies import Input, Output, State, ClientsideFunction
import dash_core_components as dcc
import dash_html_components as html
import pandas as pd
import pandas_datareader.data as pdr
import plotly.express as px
import dash_table
import yfinance as yf
from datetime import date, timedelta
import plotly.graph_objects as go
# Multi-dropdown options
from controls import COUNTIES, WELL_STATUSES, WELL_TYPES, WELL_COLORS




tickers = ["SPY","XLK","XLV","XLF","XLY","XLP","XLE","XLI","XLB","XLU","XLRE"]
tickers1 = ["XLK","XLV","XLF","XLY","XLP","XLE","XLI","XLB","XLU","XLRE"]
df = pdr.DataReader(tickers,"yahoo","2015-01-01",None)["Close"].dropna()



weekly_df = df.copy()
dic = {}
dic.update(zip(df.columns,['last' for i in range(len(df.columns))]))
offset = pd.offsets.timedelta(days=-5)
weekly_df=weekly_df.resample('W',loffset=offset).apply(dic)


rmat = (np.log(df)-np.log(df.shift(1))).dropna()
weekly_rmat = weekly_df.pct_change().dropna()



sector_weights = {"XLK":[.2806],"XLV":[.1396],"XLF":[.097],"XLY":[.1163],"XLP":[.07],"XLE":[.0199],"XLI":[.0846],"XLB":[.0263],"XLU":[.031],"XLRE":[.026],"XLC":[.1061]}
sector_weights_df=pd.DataFrame(sector_weights)

sector_descriptions = {}
descriptions = ["Technology","Healthcare","Financials","Consumer Discretionary","Consumer Staples","Energy","Industrials","Materials","Utilities","Real Estate","Communications"]
count = 0
for i in sector_weights.keys():
    sector_descriptions[i] = [descriptions[count]]
    count+=1

sector_descriptions_df = pd.DataFrame(sector_descriptions)
sector_descriptions_df =sector_descriptions_df.transpose()
sector_descriptions_df.index.name = "Ticker"
sector_descriptions_df.columns = ["Sector"]
sector_descriptions_df.reset_index(level=0,inplace=True)


sec_weights=pd.DataFrame(sector_weights)
sec_weights = sec_weights.drop(columns="XLC")
sec_weights = sec_weights.div(sec_weights.sum(axis=1),axis=0).values[0]

sec_weights

sector_rmat = rmat.drop(columns="SPY")
port_ret = sector_rmat.dot(sec_weights)
port_cum_returns = (1+port_ret).cumprod() - 1
SPY_cum_rets = (1+rmat["SPY"]).cumprod() - 1

weekly_sector_rmat = weekly_rmat.drop(columns="SPY")
weekly_port_ret = weekly_sector_rmat.dot(sec_weights)
weekly_SPY_ret = weekly_rmat["SPY"]

fig1 = go.Figure()
fig1.add_trace(go.Scatter(x=port_cum_returns.index,y=port_cum_returns.values,mode='lines',name="Weighted Sector Portfolio"))
fig1.add_trace(go.Scatter(x=SPY_cum_rets.index,y=SPY_cum_rets.values,mode='lines',name="SPY"))
fig1.update_layout(title="Weighted Sector Portfolio and SPY Cumulative Return",xaxis_title="Date",yaxis_title="Cumulative Return")

list(sector_descriptions_df.to_dict("Sector").values())[0]




def next_third_friday(d):
    """ Given a third friday find next third friday"""
    d += timedelta(weeks=4)
    return d if d.day >= 15 else d + timedelta(weeks=1)

def third_fridays(d, n):
    """Given a date, calculates n next third fridays. Will use for option expiration because
    every third friday is the main option expiration date

    """

    # Find closest friday to 15th of month
    s = date(d.year, d.month, 15)
    result = [s + timedelta(days=(4 - s.weekday()) % 7)]

    # This month's third friday passed. Find next.
    result[0] = pd.to_datetime(result[0])
    if result[0] < d:
        result[0] = next_third_friday(result[0])

    for i in range(n - 1):
        result.append(next_third_friday(result[-1]))

    return result

def yahoo_data(tickers=["AAPL","SPY"],period = "ytd"):
    '''
   Function that downloads stock and option data for multiple tickers.

   Input:
       tickers: list of equity tickers that you want to download data for

       period: string that indicates how long back you want stock data for.
               period can be "1d", "5d","1mo","3mo","6mo","1y","2y","5y","10y",
               "ytd","max"
   Output:
           Dictionary whose keys are the equity tickers in the list tickers.
           The values are a second dictionary with keys "calls", "puts", and
           "stock_data". "calls" is all of the most recent expiration's calls
           dataframe. "puts" is all of the most recent expiration's puts dataframe.
           "stock_data" is the historical stock dataframe that has each day's
           open, high, low, close, volume, etc.
   '''
    data_dic = {}
    expiration = str(pd.to_datetime(third_fridays(pd.to_datetime("today"),1))[0] - timedelta(days=1))[:10]
    expiration_vix = str(pd.to_datetime(third_fridays(pd.to_datetime("today"),1))[0] - timedelta(days=3))[:10] #VIX expires on wed not Fri
    for tick in tickers:
        tick_data = yf.Ticker(tick)
        calls_df = pd.DataFrame({})
        puts_df = pd.DataFrame({})

        if tick == "^VIX":
            option_data = tick_data.option_chain(expiration_vix)
        else:
            option_data = tick_data.option_chain(expiration)
        temp_call = option_data[0].dropna()
        temp_call = temp_call.loc[temp_call["impliedVolatility"]>0.01] #eliminate extremely illiquid options
        temp_call = temp_call.loc[temp_call["openInterest"]>100]
        temp_put = option_data[1].dropna()
        temp_put = temp_put.loc[temp_put["impliedVolatility"]>0.01] #eliminate extremely illiquid options
        temp_put = temp_put.loc[temp_put["openInterest"]>100]
        calls_df = pd.concat([calls_df, temp_call])
        puts_df = pd.concat([puts_df, temp_put])

        stock_data = tick_data.history(period= period)

        data_dic[tick] = {"calls":calls_df,"puts":puts_df,"stock_data":stock_data}

    return data_dic




def mc_VaR(price_matrix,T=252,m=1000,sector_weights = sector_weights):
    weights=pd.DataFrame(sector_weights)
    weights = weights.drop(columns="XLC")
    weights = weights.div(weights.sum(axis=1),axis=0)

    r=.01
    price_matrix = price_matrix.drop(columns="SPY")
    dt=1/T
    rmat = (np.log(price_matrix)-np.log(price_matrix.shift(1))).dropna()
    vols = rmat.std()*np.sqrt(T)
    A=rmat.corr()
    L = np.linalg.cholesky(A)
    S = price_matrix.iloc[-1,:]
    all_ret_paths=[]
    for sim in range(m):
        S_paths = [[S[j]] for j in range(len(price_matrix.columns))]
        ret_paths = [[] for j in range(len(price_matrix.columns))]
        for i in np.arange(0,(T/252)+dt,dt):
            randoms = np.array([np.random.normal() for j in range(len(S_paths))])
            epsilons = L.dot(randoms)
            for k in range(len(S_paths)):
                temp_S = S_paths[k][-1]*np.exp( ((r-.5*(vols[k]**2))*dt) + float(vols[k]*np.sqrt(dt)*epsilons[k]))
                temp_ret = np.log(S_paths[k][-1]/temp_S)
                ret_paths[k].append(temp_ret)
                S_paths[k].append(temp_S)

        ret_paths = np.array(ret_paths)

        port_path = (ret_paths.transpose().dot(weights.transpose())).transpose()[0]
        all_ret_paths.append(port_path)
    return all_ret_paths

option_data = yahoo_data(tickers =tickers)







app = dash.Dash(
    __name__, meta_tags=[{"name": "viewport", "content": "width=device-width"}]
)
server = app.server

# Create controls
county_options = [
    {"label": str(COUNTIES[county]), "value": str(county)} for county in COUNTIES
]

well_status_options = [
    {"label": str(WELL_STATUSES[well_status]), "value": str(well_status)}
    for well_status in WELL_STATUSES
]

well_type_options = [
    {"label": str(WELL_TYPES[well_type]), "value": str(well_type)}
    for well_type in WELL_TYPES
]
asset_options = [{"label":tick,"value":tick} for tick in tickers]
etf_options = [{"label":tick,"value":tick} for tick in tickers1]
mc = [50,100,500,1000,5000,10000,50000,100000]
monte_carlo_options = [{"label":m,"value":m} for m in mc]

mapbox_access_token = "pk.eyJ1IjoicGxvdGx5bWFwYm94IiwiYSI6ImNrOWJqb2F4djBnMjEzbG50amg0dnJieG4ifQ.Zme1-Uzoi75IaFbieBDl3A"

layout = dict(
    autosize=True,
    automargin=True,
    margin=dict(l=30, r=30, b=20, t=40),
    hovermode="closest",
    plot_bgcolor="#F9F9F9",
    paper_bgcolor="#F9F9F9",
    legend=dict(font=dict(size=10), orientation="h"),
    title="Satellite Overview",
    mapbox=dict(
        accesstoken=mapbox_access_token,
        style="light",
        center=dict(lon=-78.05, lat=42.54),
        zoom=7,
    ),
)

# Create app layout
app.layout = html.Div(
    [
        html.Div(
            [
                html.Div(
                    [
                        html.Div(
                            [
                                html.H3(
                                    "S&P 500 Volatility Analysis",
                                    style={"margin-bottom": "0px"},
                                ),
                                html.H5(
                                    "Gregory Giordano", style={"margin-top": "0px"}
                                ),
                            ]
                        )
                    ],
                    className="one-half column",
                    id="title",
                ),
                html.Div(
                    [
                        html.A(
                            html.Button("Learn More", id="learn-more-button"),
                            href="http://quantlabs.net/academy/download/free_quant_instituitional_books_/[JP%20Morgan]%20Correlation%20Vechicles%20-%20Techniques%20for%20Trading%20Equity%20Correlation.pdf",
                        )
                    ],
                    className="one-third column",
                    id="button",
                ),
            ],
            id="header",
            className="row flex-display",
            style={"margin-bottom": "25px"},
        ),
        html.Div(
            [
                html.Div(
                    [
                        html.P(
                            "Select Asset(s):",
                            className="control_label",
                        ),
                        dcc.Dropdown(
                            id="asset_select",
                            options = asset_options,
                            multi=True,
                            value = ["SPY"],
                            className="dcc_control",
                        ),
                        html.P("SPDR Ticker Sector Descriptions:", className="control_label"),

                        dash_table.DataTable(
                        id="sector-table",
                        columns = [{"name":i,"id":i} for i in sector_descriptions_df.columns],
                        data = sector_descriptions_df.to_dict("rows"),
                        css=[{'selector': 'table', 'rule': 'table-layout: fixed'}],
                        style_cell_conditional=[
                                {'if': {'column_id': 'Ticker'},
                                 'width': '70px'},
                                {'if': {'column_id': 'Sector'},
                                 'width': '70px'},
                            ],
                        style_cell = {
                            'font-family':"sans",
                            'text-align':'center'
                        }
                        ),


                    ],
                    className="pretty_container four columns",
                    id="cross-filter-options",
                ),

                html.Div(
                    [


                        html.Div(
                            [
                                html.Div([
                                dcc.Graph(id="stock_graph")

                                ],className="pretty_container"),

                                html.Div([
                                    dcc.Graph(id="weight-pie-chart",
                                        figure = px.pie(
                                        sector_weights_df,names=sector_weights_df.columns,values = sector_weights_df.values[0],
                                        title = "S&P 500 Sector Weights"
                                        )
                                        )],className="pretty_container")



                            ],
                            id="info-container",
                            className="row flex-display",
                        ),


                    ],
                    id="right-column",
                    className="eight columns",
                ),
            ],
            className="row flex-display",
        ),
        html.Div([html.H4(
            "Risk Analysis", style={"margin-top": "10px", "text-align":'center'}
        )],style ={"margin-left":100,"margin-right":40} ,className = "row flex-display"),
        html.Div([

            html.Div(
                [
                    html.P(
                        "Select Asset(s) For Skew Chart:",
                        className="control_label",
                    ),
                    dcc.Dropdown(
                        id="asset_select1",
                        options = asset_options,
                        multi=True,
                        value = ["SPY"],
                        className="dcc_control",
                    ),
                    html.P("Select Call or Put Option:", className="control_label"),
                    dcc.RadioItems(
                        id="call-put-selector",
                        options=[
                            {"label": "Call", "value": "Call"},
                            {"label": "Put", "value": "Put"}
                        ],
                        value="Call",
                        labelStyle={"display": "inline-block"},
                        className="dcc_control",
                    ),
                    html.P(
                        "Select Number of Monte Carlo Simulations to Perform:",
                        className="control_label",
                    ),
                    dcc.Dropdown(
                        id="mc_select",
                        options = monte_carlo_options,
                        multi= False,
                        value = 50,
                        className="dcc_control",
                    ),
                    dcc.Loading(
                        id = "loading-1",
                        type = "circle",
                        children=[html.Div(id="loading-output")]
                    ),

                    html.P("Risk Statistics:", className="control_label"),

                    dash_table.DataTable(
                    id="risk-table",
                    columns = [{"name":i,"id":i} for i in ['Metric (Annualized)','SPY','Weighted Portfolio']],
                    css=[{'selector': 'table', 'rule': 'table-layout: fixed'}],
                    style_cell_conditional=[
                            {'if': {'column_id': 'Metric (Annualized)'},
                             'width': '50px'},
                            {'if': {'column_id': 'SPY'},
                             'width': '50px'},
                             {'if': {'column_id': 'Weighted Portfolio'},
                              'width': '50px'}
                        ],
                    style_cell = {
                        'font-family':"sans",
                        'text-align':'center'
                    }
                    ),

                ],
                className="pretty_container four columns",
                id="risk-stats",
            ),
            html.Div(
                [

                    html.Div(
                        [
                            html.Div([
                            dcc.Graph(id="box-plots",
                                        figure=px.box(rmat,y=rmat.columns,title="ETF Return Distributions"))

                            ],className="pretty_container"),

                            html.Div([
                            dcc.Graph(id="skew-graph")

                            ],className="pretty_container"),

                            html.Div([
                                dcc.Graph(id="mc-graph")
                                    ],className="pretty_container")



                        ],
                        id="risk-container",
                    ),


                ],
                id="right-column1",
                className="eight columns",
            ),

        ],className="row flex-display"),

        html.Div([html.H4(
            "Correlation Analysis", style={"margin-top": "10px", "text-align":'center'}
        )],style ={"margin-left":100,"margin-right":40} ,className = "row flex-display"),

        html.Div([

            html.Div(
                [
                    html.P(
                        "Select Asset For Scatter Plot:",
                        className="control_label",
                    ),
                    dcc.Dropdown(
                        id="asset_select2",
                        options = etf_options,
                        multi=False,
                        value = "XLK",
                        className="dcc_control",
                    ),
                    html.P("Select Call or Put Option for Implied Correlation:", className="control_label"),
                    dcc.RadioItems(
                        id="call-put-selector1",
                        options=[
                            {"label": "Call", "value": "Call"},
                            {"label": "Put", "value": "Put"}
                        ],
                        value="Call",
                        labelStyle={"display": "inline-block"},
                        className="dcc_control",
                    ),

                    html.P("Current Implied vs Realized Correlation SPY and Weighted Portfolio: ", className="control_label"),

                    dash_table.DataTable(
                    id="corr-table",
                    columns = [{"name":i,"id":i} for i in ['Metric','Value']],
                    css=[{'selector': 'table', 'rule': 'table-layout: fixed'}],
                    style_cell_conditional=[
                            {'if': {'column_id': 'Metric'},
                             'width': '70px'},
                            {'if': {'column_id': 'Value'},
                             'width': '70px'}
                        ],
                    style_cell = {
                        'font-family':"sans",
                        'text-align':'center'
                    }
                    ),

                ],
                className="pretty_container four columns",
                id="corr-stats",
            ),
            html.Div(
                [

                    html.Div(
                        [
                            html.Div([
                            dcc.Graph(id="price-charts",figure=fig1)

                            ],className="pretty_container"),

                            html.Div([
                            dcc.Graph(id="etf-scatter")

                            ],className="pretty_container"),



                            html.Div([
                                dcc.Graph(id="corr-graph")
                                    ],className="pretty_container")



                        ],
                        id="corr-container",
                    ),


                ],
                id="right-column2",
                className="eight columns",
            ),

        ],className="row flex-display"),



    ],
    id="mainContainer",
    style={"display": "flex", "flex-direction": "column"},
)

def implied_corr_calc(tickers,cp,weights,atm_indicies):
    num_result=0
    vols = []
    for i in range(len(tickers)):
        vol=option_data[tickers[i]][cp].reset_index()["impliedVolatility"][atm_indicies[i]]
        num_result+= weights[i]**2 * vol**2
        vols.append(vol)

    denom_result = 0
    for i in range(len(tickers)):
        for j in range(1,len(tickers)):
            denom_result+= weights[i]*weights[j]*vols[i]*vols[j]

    spy_close = df["SPY"][-1]
    temp_option_data = option_data["SPY"][cp].reset_index()
    dif_lst = [abs(spy_close-temp_option_data["strike"][i]) for i in range(len(temp_option_data.index))]
    atm_index = dif_lst.index(min(dif_lst))
    SPY_vol = temp_option_data["impliedVolatility"][atm_index]

    implied_corr = (SPY_vol**2 - num_result)/(2*denom_result)
    return implied_corr

def realized_corr_calc(month_returns,weights):
    '''Returns list of 30-day realized correlation calculation'''

    sector_returns = month_returns.drop(columns="SPY")
    corrs = []

    num_result = 0
    for i in range(len(sector_returns.columns)):
        tick = sector_returns.columns[i]
        sigma2 = (sector_returns[tick].std()*np.sqrt(252))**2
        num_result += (weights[i]**2) * sigma2

    spy_var = (month_returns["SPY"].std()*np.sqrt(252))**2
    num = spy_var - num_result
    denom_result = 0
    for i in range(len(sector_returns.columns)):
        tick1 = sector_returns.columns[i]
        sigma1 = sector_returns[tick1].std()*np.sqrt(252)
        for j in range(1,len(sector_returns.columns)):
            tick2 = sector_returns.columns[j]
            sigma2 = sector_returns[tick2].std()*np.sqrt(252)
            denom_result+= weights[i]*weights[j]*sigma1*sigma2

    realized_corr = num/(2*denom_result)
    return realized_corr





def time_to_maturity(option_symbol):
    '''
    Function that outputs the time to maturity of a given option contract

    Input:
        String of option symbol. For example "AMZN200925C05000000"
    Output:
        Time to maturity of given option contract as a unit of (days to maturity/365)

    '''
    for i in range(len(option_symbol)):
        if option_symbol[i].isnumeric():
            year = "20" + option_symbol[i:i+2]
            month = option_symbol[i+2:i+4]
            day = option_symbol[i+4:i+6]
            expiry_date = pd.to_datetime(year+"-"+month+"-"+day)
            delta=(expiry_date - pd.to_datetime("today")).days
            return str(expiry_date.month) + "/" + str(expiry_date.day) + "/" + str(expiry_date.year)

# Helper functions
@app.callback( Output('stock_graph','figure'), [Input('asset_select','value')] )
def drop_down_callback( drop_down ):
    temp_df = df[drop_down]
    return px.line(temp_df,x=temp_df.index,y=temp_df.columns,title="Asset Prices Over Time")


# update skew graph
@app.callback(Output('skew-graph','figure'),[Input('asset_select1','value'), Input('call-put-selector','value')])
def skew_graph_gen(tickers,cp):
    fig = go.Figure()
    for tick in tickers:
        call_data = option_data[tick]["calls"].reset_index()
        put_data =  option_data[tick]["puts"].reset_index()
        S = option_data[tick]["stock_data"]["Close"][-1]
        if cp == "Call":
            strikes = round(call_data["strike"]/S,2)
            ivs = call_data["impliedVolatility"]
        else:
            strikes = round(put_data["strike"]/S,2)
            ivs = put_data["impliedVolatility"]

        fig.add_trace(go.Scatter(x=strikes,y=ivs,name=tick,mode="markers"))

    exp = time_to_maturity(call_data["contractSymbol"][0])
    fig.update_layout(title=exp+" Expiration Implied Volatility Skew Graph",yaxis_zeroline=False, xaxis_zeroline=False, xaxis_title="Strike Percent of ATM", yaxis_title = "Implied Volatility")
    return fig




@app.callback([Output('mc-graph','figure'),Output('loading-output','children'),Output('risk-table','data')],[Input('mc_select','value')])
def mc_graph_gen(m):
    return_paths = mc_VaR(df,m=m)
    x_data = len(return_paths[0])
    all_cums, all_std = [],[]
    fig = go.Figure()
    for i in range(len(return_paths)):
        cum_ret = (1+return_paths[i]).cumprod() - 1
        fig.add_trace(go.Scatter(x=list(range(x_data)),y=cum_ret,mode='lines',name="Path "+str(i+1)))
        all_cums.append(cum_ret)
        all_std.append(return_paths[i].std()*np.sqrt(252))

    fig.update_layout(title="Weighted Sector Portfolio Monte Carlo Paths",xaxis_title="Day",yaxis_title="Return")
    #### risk table updates
    all_exps = [all_cums[i][-1] for i in range(len(all_cums))]
    var_95 = np.percentile(all_exps,5)
    mc_var =np.percentile(all_cums,5)

    below_var = np.array([x for x in all_exps if x<mc_var])
    mc_CVaR = str(round(below_var.mean()*100,2))+'%'
    mc_vol = str(round(np.mean(all_std)*100,2))+'%'
    mc_var = str(round(np.percentile(all_cums,5)*100,2))+'%'

    SPY_rets = (np.log(df)-np.log(df.shift(1))).dropna()["SPY"]
    SPY_vol = str(round(SPY_rets.std() * np.sqrt(252)*100,2))+'%'
    SPY_rets = SPY_rets.values
    SPY_var = str(round(np.percentile(SPY_rets,5)*np.sqrt(252)*100,2))+'%'
    below_SPY_var = np.array([x for x in SPY_rets if x<np.percentile(SPY_rets,5)])
    SPY_cvar = str(round(np.mean(below_SPY_var)*np.sqrt(252)*100,2))+'%'
    ############### Build table #############

    mc_stats = [mc_vol,mc_var,mc_CVaR]
    SPY_stats = [SPY_vol,"-23.73%","-29.12%"]
    metrics = ["Volatiltiy","95% VaR","95% CVaR"]
    risk_df = pd.DataFrame({"Metric (Annualized)":metrics,"SPY":SPY_stats,"Weighted Portfolio":mc_stats})



    columns = [{"name":i,"id":i} for i in risk_df.columns],
    data = risk_df.to_dict("rows")



    return fig, html.P("Simulations Complete!"),data

@app.callback(Output('etf-scatter','figure'),[Input('asset_select2','value')])
def scatter_gen(ticker):
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=rmat["SPY"].values,y=rmat[ticker].values,mode="markers"))
    fig.update_layout(title="SPY vs "+ticker+" Daily Returns",yaxis_zeroline=False, xaxis_zeroline=False, xaxis_title="SPY", yaxis_title = ticker)
    return fig



@app.callback([Output('corr-graph','figure'),Output('corr-table','data')],[Input('call-put-selector1','value')])
def corr_graph_gen(cp):
    moving_30_day = []
    days_back = 15

    for i in range(days_back,len(rmat.index)):
        month_returns = rmat[i-21:i]
        corr_30=realized_corr_calc(month_returns,sec_weights)
        moving_30_day.append(corr_30)
    dates = rmat.index[days_back:]
    ### Implied corr calculation
    atm_indicies = []
    for i in range(len(tickers1)):
        close = df[tickers1[i]][-1]
        if cp == "Call":
            temp_option_data = option_data[tickers1[i]]["calls"].reset_index()
        else:
            temp_option_data = option_data[tickers1[i]]["puts"].reset_index()

        dif_lst = [abs(close-temp_option_data["strike"][i]) for i in range(len(temp_option_data.index))]
        atm_index = dif_lst.index(min(dif_lst))
        atm_indicies.append(atm_index)

    if cp=="Call":
        implied_corr = implied_corr_calc(tickers1,"calls",sec_weights,atm_indicies)
    else:
        implied_corr = implied_corr_calc(tickers1,"puts",sec_weights,atm_indicies)

    implied_graph = [implied_corr for i in range(len(dates))]
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=dates,y=moving_30_day,mode="lines",name="Portfolio SPY Realized Correlation"))
    fig.add_trace(go.Scatter(x=dates,y=implied_graph,mode="lines",name="Current Implied Correlation"))
    fig.update_layout(title="Historical Realized Correlation vs Current Implied Correlation of SPY and Weighted Portfolio",yaxis_zeroline=False, xaxis_zeroline=False, xaxis_title="Date", yaxis_title = "Correlation")

    metrics=["Implied Correlation","Realized Correlation"]
    values = (np.array([implied_corr,moving_30_day[-1]])*100).round(2)
    values = [str(values[i])+"%" for i in range(len(values))]
    corr_df = pd.DataFrame({"Metric":metrics,"Value":values})
    data = corr_df.to_dict("rows")
    return fig,data

# Main
if __name__ == "__main__":
    app.run_server()
